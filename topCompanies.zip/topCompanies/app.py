from flask import render_template
from flask_sqlalchemy import SQLAlchemy
from flask import Flask, request
import pandas as pd
import plotly.express as px

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mssql+pyodbc://@LAPTOP-ILO5R7QF/web_scrapping?trusted_connection=yes&driver=ODBC+Driver+17+for+SQL+Server'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Company(db.Model):
    __tablename__ = 'company'
    Rank = db.Column(db.Integer, primary_key=True)
    Name = db.Column(db.String, nullable=True)
    Industry = db.Column(db.String, nullable=True)
    Revenue = db.Column(db.Float, nullable=True)
    Profit = db.Column(db.Integer, nullable=True)
    NumberOfEmployees = db.Column(db.Integer, nullable=True)
    Headquaters = db.Column(db.String, nullable=True)
    RevenuePerEmployee = db.Column(db.Float, nullable=True)

# Function to calculate total revenue in billion and percentage by industry
def calculate_dashboard_data():
    # Query the data from the database
    data = Company.query.all()

    # Create a DataFrame from the query result
    df = pd.DataFrame([(company.Industry, company.Revenue) for company in data], columns=['Industry', 'Revenue'])

    # Calculate total revenue in billion
    total_revenue_billion = df['Revenue'].sum() / 1e9

    # Calculate percentage by industry
    percentage_by_industry = df.groupby('Industry')['Revenue'].sum() / df['Revenue'].sum() * 100

    return total_revenue_billion, percentage_by_industry

# Route for the dashboard

@app.route('/')
def index():
    # Query the data from the database
    data = Company.query.all()

    return render_template('index.html', data=data)

@app.route('/home')
def home():
    # Query the data from the database
    data = Company.query.all()

    return render_template('home.html', data=data)
@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/extrafeature', methods=['GET', 'POST'])
def extrafeature():
    if request.method == 'POST':
        rank = request.form.get('rank')
        rank_from = request.form.get('rank_from')
        rank_to = request.form.get('rank_to')

        if rank and rank.isdigit() and 1 <= int(rank) <= 50:
            # Query the data for the specified rank from the database
            company = Company.query.filter_by(Rank=int(rank)).first()
            return render_template('extrafeature.html', company=company, rank=int(rank))

        elif rank_from and rank_to and rank_from.isdigit() and rank_to.isdigit() and 1 <= int(rank_from) <= 50 and 1 <= int(rank_to) <= 50:
            # Query the data for the specified rank range from the database
            companies = Company.query.filter(Company.Rank.between(int(rank_from), int(rank_to))).all()
            return render_template('extrafeature.html', companies=companies)

        else:
            return render_template('extrafeature.html', error_message='Invalid input. Please enter a valid rank or rank range.')

    return render_template('extrafeature.html')

@app.route('/dashboard')
def dashboard():
    # Query the data from the database
    data = Company.query.all()

    # Create a DataFrame for the pie chart from the query result
    pie_df = pd.DataFrame([(company.Industry, company.Revenue) for company in data], columns=['Industry', 'Revenue'])

    # Aggregate data by summing revenue for each industry
    aggregated_pie_data = pie_df.groupby('Industry', as_index=False).sum()

    # Create a pie chart with Plotly Express
    pie_chart_fig = px.pie(aggregated_pie_data, names='Industry', values='Revenue',
                           title='Total Revenue (in billion($)) by Industry in top 50',
                           labels={'Revenue': 'Total Revenue (in Billion ($))'},
                           template='plotly',
                           )

    # Customize the data labels to display values only
    pie_chart_fig.update_traces(textinfo='value', textposition='inside')

    # Adjust the size of the pie chart
    pie_chart_fig.update_layout(height=500, width=700)

    # Create a DataFrame for the global map from the query result
    map_df = pd.DataFrame([(company.Name, company.Headquaters) for company in data], columns=['Name', 'Headquaters'])

    # Aggregate data by counting the number of companies by country
    aggregated_map_data = map_df['Headquaters'].value_counts().reset_index()
    aggregated_map_data.columns = ['Country', 'Number of Companies']

    # Create a global map with Plotly Express
    map_chart_fig = px.choropleth(aggregated_map_data, locations='Country', locationmode='country names',
                                  color='Number of Companies',
                                  title='Number of Companies in top 50 by Country',
                                  labels={'Number of Companies': 'Number of Companies'},
                                  template='plotly_dark',
                                  )

    # Adjust the size of the global map
    map_chart_fig.update_layout(height=500, width=700)

    # Create a DataFrame for the bubble chart from the query result (top 10 companies)
    bubble_df = pd.DataFrame([(company.Name, company.Revenue, company.Profit, company.NumberOfEmployees) for company in data[:10]],
                              columns=['Name', 'Revenue', 'Profit', 'NumberOfEmployees'])

    # Create a bubble chart with Plotly Express for top 10 companies
    bubble_chart_fig = px.scatter(bubble_df, x='Revenue', y='Profit', size='NumberOfEmployees', text='Name',
                                  title='Revenue vs Profit (Top 10 Companies) where bubble size represent number of employees',
                                  labels={'Revenue': 'Revenue (in Billion $)',
                                          'Profit': 'Profit (in Billion $)',
                                          'NumberOfEmployees': 'Number of Employees'},
                                  template='plotly',
                                  )

    # Adjust the size of the bubble chart for top 10 companies
    bubble_chart_fig.update_layout(height=800, width=1200)

    # Sort all_data based on profit and take top 10 rows
    #bar_df = pd.DataFrame(
     #   [(company.Name, company.Profit) for company in sorted(data, key=lambda x: x.Profit, reverse=True)[:10]],
     #   columns=['Name', 'Profit'])
    bar_df = pd.DataFrame(
        [(company.Name, company.Profit) for company in
         sorted(data, key=lambda x: x.Profit if x.Profit is not None else float('-inf'), reverse=True)[:10]],
        columns=['Name', 'Profit']
    )
    # Create a vertical bar chart for the top 10 profitable companies with data labels
    bar_chart_fig_top10 = px.bar(bar_df, x='Name', y='Profit',
                                 title='Top 10 most Profitable Companies',
                                 labels={'Profit': 'Profit (in billion($))'},
                                 template='plotly',
                                 )

    # Display data labels on the bars
    bar_chart_fig_top10.update_traces(text=bar_df['Profit'], textposition='inside')

    # Adjust the size of the vertical bar chart for top 10
    bar_chart_fig_top10.update_layout(height=600, width=900)

    # Render this chart in the HTML template
    bar_chart_html_top10 = bar_chart_fig_top10.to_html(full_html=False)

    return render_template('dashboard.html', pie_chart_html=pie_chart_fig.to_html(full_html=False),
                           map_chart_html=map_chart_fig.to_html(full_html=False),
                           bubble_chart_html=bubble_chart_fig.to_html(full_html=False),
                           bar_chart_top10_html=bar_chart_html_top10
                           )







if __name__ == '__main__':
    app.run(debug=True)
