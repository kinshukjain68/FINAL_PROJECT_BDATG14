import pyodbc
import pandas as pd
import pyodbc
from sqlalchemy import create_engine, types
import numpy as np


# Replace 'your_server_name' and 'your_database_name' with your SQL Server and database details
server_name = 'LAPTOP-ILO5R7QF'
database_name = 'web_scrapping'

def connect_to_sql( ):
    print("hellow")



def connect_to_sql_server( df):
    # Create a connection string using Windows authentication
    connection_string = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server_name};DATABASE={database_name};Trusted_Connection=yes;'

    try:
        # Create SQLAlchemy engine
        engine = create_engine(f"mssql+pyodbc:///?odbc_connect={connection_string}")

        # Use pandas to_sql method with the SQLAlchemy engine

        #df.to_sql(name='company_stage', con=engine,  index=True)
        #print("loaded table")

        df.to_sql(name='company_stage', con=engine, index=False, if_exists='replace', dtype={
            'Rank': types.INT,  # Adjust the data types as needed
            'Name': types.String,
            'Industry': types.String,
            'Revenue': types.String,
            'Profit': types.String,
            'Employees': types.String,
            'Headquaters': types.String,
            'RevenuePerEmployee': types.String
        })
        print("Stage Table loaded successfully.")

        # Connect to the database using pyodbc
        conn = pyodbc.connect(connection_string)
        cursor = conn.cursor()

        # Execute the stored procedure
        cursor.execute("EXEC sp_populate_company")

        # Commit the changes
        conn.commit()

        print("Stored procedure executed successfully.")

    except pyodbc.Error as e:
        print(f"Error: {e}")



