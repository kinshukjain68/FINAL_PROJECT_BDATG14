import requests
from bs4 import BeautifulSoup
import pandas as pd

def get_table_data_as_dataframe(url):
    # Fetch the webpage
    response = requests.get(url)

    # Parse the HTML content
    soup = BeautifulSoup(response.text, 'html.parser')

    # Find the table you're interested in
    table = soup.find('table')

    # Extract data rows
    data_rows = []
    for row in table.find_all('tr')[1:]:  # Skip the header row
        columns = row.find_all('td')
        row_data = [col.text.strip() for col in columns]
        if row_data:  # Add only non-empty rows
            data_rows.append(row_data)

    # Determine the number of columns from the data
    num_cols = max(len(row) for row in data_rows)

    # Create DataFrame without column names
    return pd.DataFrame(data_rows, columns=[f'Column {i+1}' for i in range(num_cols)])

def transform_dataframe():
    # URL of the page
    url = 'https://en.wikipedia.org/wiki/List_of_largest_companies_by_revenue'

    # Call the function and get the DataFrame
    df = get_table_data_as_dataframe(url)
    transformed_df = df[['Column 1', 'Column 2', 'Column 3', 'Column 4', 'Column 5', 'Column 6', 'Column 9']]
    transformed_df.columns = ['Name', 'Industry', 'Revenue', 'Profit', 'Employees', 'Headquaters', 'RevenuePerEmployee']
    # transformed_df['RowNumber'] = transformed_df.reset_index().index + 1
    transformed_df.insert(0, 'Rank', range(1, len(transformed_df) + 1))
    return transformed_df
