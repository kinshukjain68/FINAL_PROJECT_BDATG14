# This is a sample Python script.
import requests
from bs4 import BeautifulSoup
import pandas as pd
# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import web_scrapping
import database_connection

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    pd.set_option('display.max_columns',None)
    pd.set_option('display.max_rows',None)
    df = web_scrapping.transform_dataframe();
    database_connection.connect_to_sql_server(df);


# See PyCharm help at https://www.jetbrains.com/help/pycharm/
